## Web Design and Programming Course Material
***material detail will be updated soon***

1. Week 2 - Intro to HTML
2. Week 3 - Intro to CSS
3. Week 4 - Intro to JS
4. Week 5 - Pencil (KUIS)
6. Week 6 - jQuery
7. Week 7 - Bootstrap
8. Week 8 - Intro to PHP (Condition, Loop, Function)
