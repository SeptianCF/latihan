<?php
    for (start; condition; increment) {
        //statement
    }
?>