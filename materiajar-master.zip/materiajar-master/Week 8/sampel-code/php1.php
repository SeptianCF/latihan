<?php
    if (kondisi) {
        //statement
    }

    if (kondisi) {
        //statement 1
    } else {
        //statement 2
    }

    if (kondisi) {
        //statement 1
    } else if (kondisi2) {
        // statement 2
    } else {
        // statement 3
    }
?>