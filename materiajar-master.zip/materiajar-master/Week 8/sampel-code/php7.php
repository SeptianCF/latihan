<?php
    function salam() {
        echo "Selamat Pagi!";
    }
    function salam2($nama) {
        echo "Selamat Pagi " . $nama;
    }
    function salam3($nama="afif") {
        echo "Selamat Pagi " . $nama;
    }
?>

