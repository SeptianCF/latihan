<?php
    function jumlah($value1, $value2) {
        $sum = $value1 + $value2;
        return $sum;
    }
?>




