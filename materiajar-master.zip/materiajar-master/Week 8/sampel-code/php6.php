<?php
    $hari = array(
        1 => "senin",
        2 => "selasa",
        3 => "rabu"
    );

    foreach ($hari as $key => $value) {
        echo "Key ke " . $key . "adalah " . $value;
        echo "<br/>";
    }
?>