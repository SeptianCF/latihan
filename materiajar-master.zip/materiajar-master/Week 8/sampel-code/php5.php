<?php
    $hari = array("senin", "selasa", "rabu");
    for ($i = 0; $i < 3; $i++) {
        echo $hari[i];
        echo "<br/>";
    }

    foreach ($hari as $h) {
        echo $h;
        echo "<br/>";
    }
?>