<?php
    while(condition) {
        //statement
        increment;
    }
?>